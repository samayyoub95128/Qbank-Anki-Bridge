// content.js
//
// IMPORTANT, READ FIRST:
// extractQid() and isAnswered() below are best-effort guesses at how to
// read state out of the live page. I can't inspect your actual logged-in
// UWorld/Amboss session, and both sites are proprietary SPAs whose markup
// changes over time, so treat the patterns here as a starting point you
// may need to adjust — the README's Troubleshooting section walks through
// how, and there are manual override controls in the panel itself so a
// bad auto-detect never fully blocks you.

const SITE = location.hostname.includes("amboss.com") ? "amboss" : "uworld";

// ---- 1. Extract a question ID from the current page ----------------------

// Returns { qid, confidence }. "confidence" tells the UI whether to show a
// "verify this" hint — the URL-based UWorld fallback in particular has
// already produced at least one false positive (a block/session id that
// happened to look plausible), so it's marked low rather than silently
// trusted.
function extractQid() {
  return SITE === "amboss" ? extractAmbossCode() : extractUworldQid();
}

function extractUworldQid() {
  const dataAttrCandidates = ["[data-question-id]", "[data-qid]", "[data-item-id]"];
  for (const sel of dataAttrCandidates) {
    const el = document.querySelector(sel);
    if (el) {
      const val =
        el.getAttribute("data-question-id") ||
        el.getAttribute("data-qid") ||
        el.getAttribute("data-item-id");
      if (val && val.trim()) return { qid: val.trim(), confidence: "high" };
    }
  }

  // Visible "Question Id: 22124" text. UWorld typically prints this near
  // the flag/report-a-problem control, often only once you've answered —
  // require 3-7 digits so we don't grab an unrelated small number (a
  // timer, a block position) that happens to sit near similar text.
  const bodyText = document.body.innerText || "";
  const labelPatterns = [
    /Question\s*Id\s*[:#]?\s*(\d{3,7})/i,
    /\bQID\s*[:#]?\s*(\d{3,7})/i,
    /\bQ\.?ID\.?\s*[:#]?\s*(\d{3,7})/i
  ];
  for (const re of labelPatterns) {
    const m = bodyText.match(re);
    if (m) return { qid: m[1], confidence: "high" };
  }

  // Low-confidence last resort: a plausible ID out of the URL. This has
  // already misfired once (grabbed a block/session number instead of the
  // real question id), so it's flagged rather than trusted outright.
  const url = new URL(location.href);
  const paramCandidates = ["qid", "questionId", "itemId", "id"];
  for (const p of paramCandidates) {
    if (url.searchParams.has(p)) {
      return { qid: url.searchParams.get(p), confidence: "low" };
    }
  }
  const pathParts = url.pathname.split("/").filter(Boolean);
  if (pathParts.length) {
    return { qid: pathParts[pathParts.length - 1], confidence: "low" };
  }

  return { qid: null, confidence: "none" };
}

// Amboss doesn't print a plain question ID anywhere on the question page
// (the address, e.g. /us/questions/867MaO55JO/70, is session id + question
// number, not what your cards are tagged with). Your #AMBOSS-tagged cards
// are keyed on a short code like "klamCk" or "y0adiQ" that Amboss shows,
// bottom-left next to a copy icon, inside the "Find related AnKing cards"
// dialog behind the question's own GET ANKI CARDS button.
//
// So: the first time you open that dialog on a question, the code is read
// from it and remembered for that question's address (also saved across
// sessions). After that the panel finds the cards by itself — even after
// you close the dialog, and whenever you come back to that question.
const ambossCodes = new Map(); // question address (pathname) -> short code

function rememberAmbossCode(path, code) {
  if (ambossCodes.get(path) === code) return;
  ambossCodes.set(path, code);
  chrome.storage.local.set({ [`qab_ac_${path}`]: code });
}

// A code is 5-10 letters/digits with at least a digit or an uppercase letter
// somewhere AFTER the first character. That's what separates it from the
// ordinary words around it ("Copied", "Help", "AnkiHub" is excluded below).
function looksLikeAmbossCode(text) {
  if (!/^[A-Za-z0-9]{5,10}$/.test(text)) return false;
  if (/^[A-Z]+$/.test(text)) return false; // an ALL-CAPS word, not a code
  return /[0-9]/.test(text) || /[A-Z]/.test(text.slice(1));
}

function readCodeFromAmbossModal() {
  const heading = Array.from(document.querySelectorAll("*")).find(
    (el) =>
      el.children.length === 0 &&
      /find related anking cards/i.test(el.textContent || "")
  );
  if (!heading) return { modalOpen: false, code: null };

  // Search only inside the dialog itself, so nothing else on the page can match.
  let scope = heading.closest('[role="dialog"], [aria-modal="true"], dialog');
  if (!scope) {
    scope = heading;
    for (let i = 0; i < 6 && scope.parentElement; i++) scope = scope.parentElement;
  }

  const txt = (el) => (el.textContent || "").trim();
  const candidates = Array.from(scope.querySelectorAll("*")).filter((el) => {
    if (!looksLikeAmbossCode(txt(el))) return false;
    if (el.closest("a")) return false; // e.g. the "AnkiHub" link
    // innermost element only (the code may sit beside a copy-icon <svg>)
    return !Array.from(el.children).some((c) => looksLikeAmbossCode(txt(c)));
  });
  // Prefer the one inside a button (the code is a click-to-copy button).
  candidates.sort(
    (a, b) =>
      (b.closest('button, [role="button"]') ? 1 : 0) -
      (a.closest('button, [role="button"]') ? 1 : 0)
  );
  return { modalOpen: true, code: candidates.length ? txt(candidates[0]) : null };
}

function extractAmbossCode() {
  const path = location.pathname;
  const fromModal = readCodeFromAmbossModal();
  if (fromModal.code) {
    rememberAmbossCode(path, fromModal.code);
    return { qid: fromModal.code, confidence: "medium" };
  }
  const saved = ambossCodes.get(path);
  if (saved) return { qid: saved, confidence: "medium" };
  return {
    qid: null,
    confidence: "none",
    needsAction: fromModal.modalOpen ? "amboss-code-not-found" : "amboss-open-modal"
  };
}

// ---- 1b. Detect whether the current question has been answered -----------
//
// Same caveat as extractQid(): pattern-matched against text that typically
// only appears once an explanation/rationale is showing. If this doesn't
// fire reliably on your layout, use the "Reveal cards now" button in the
// compact view as a manual override rather than waiting on this to be
// perfect — and see the README for how to tighten these patterns.
function isAnswered() {
  const bodyText = document.body.innerText || "";
  if (SITE === "amboss") {
    // Before you answer, Amboss shows SHOW ANSWER / SKIP. Once the explanation
    // is up it adds GIVE FEEDBACK (and the NEXT button).
    return /give feedback/i.test(bodyText) || /learning objective/i.test(bodyText);
  }
  const patterns = [
    /Educational Objective/i,
    /Learning Objective/i,
    /\bRationale\b/i,
    /Correct Answer\b/i,
    /\bIncorrect\b/i
  ];
  return patterns.some((re) => re.test(bodyText));
}

// ---- 2. Overlay panel ------------------------------------------------------

let panelEl = null;
let lastQid = null;
let lastConfidence = "none";
let lastResult = null; // cached AnkiConnect lookup result for lastQid, when found
let lastAnswered = false;
let manualReveal = false; // forces the full card view even if isAnswered() hasn't fired
let manualOverride = null; // set when the user types a QID in themselves
let seenQids = new Set();
let lastSeenBefore = false; // was this QID already seen before THIS visit to it?

// UI preferences that persist across page loads / sessions (chrome.storage.local):
//   mode:      "pre"  = show active/suspended counts as soon as a question loads
//              "post" = show nothing about the cards until you've answered
//   minimized: panel collapsed down to a tiny tab at the bottom of the screen
//   size:      {width, height} the user dragged the panel to (null = default)
//   position:  {top, left} the user dragged the panel to (null = default corner)
const MIN_W = 260;
const MIN_H = 140;
const uiState = { mode: "pre", minimized: false, size: null, position: null };
let lastNoQidKey = null; // see poll(): tracks the "no ID yet" hint state
let pageActive = null; // are we on a page that has a question? (null = not checked yet)
let uiReady = false; // poll() waits for this so a saved "post" mode can never flash cards on load
let tabEl = null;

function ensurePanel() {
  if (panelEl) return panelEl;
  panelEl = document.createElement("div");
  panelEl.id = "qab-panel";
  panelEl.innerHTML = `
    <div id="qab-header">
      <span id="qab-title">Anki</span>
      <div id="qab-header-actions">
        <button id="qab-mode" type="button"></button>
        <button id="qab-collapse" type="button" title="Minimize to a small tab at the bottom of the screen">–</button>
      </div>
    </div>
    <div id="qab-banner" style="display:none"></div>
    <div id="qab-body">
      <div id="qab-status">Loading…</div>
      <div id="qab-compact-summary"></div>
      <button id="qab-reveal-btn" style="display:none">Reveal cards now</button>
      <div id="qab-cards"></div>
      <div id="qab-override-row">
        <input id="qab-override-input" type="text" placeholder="Manual QID override…" />
        <button id="qab-override-btn">Use</button>
        <button id="qab-override-clear" title="Clear override, resume auto-detect">Auto</button>
      </div>
    </div>
    <div class="qab-grip" id="qab-grip-tr" title="Drag to resize · double-click to reset size"></div>
    <div class="qab-grip" id="qab-grip-br" title="Drag to resize · double-click to reset size"></div>
  `;
  document.documentElement.appendChild(panelEl);

  // The tiny tab that stands in for the panel while it's minimized.
  tabEl = document.createElement("button");
  tabEl.id = "qab-tab";
  tabEl.type = "button";
  tabEl.textContent = "Anki";
  tabEl.title = "Show the Anki panel";
  tabEl.addEventListener("click", () => setMinimized(false));
  document.documentElement.appendChild(tabEl);

  panelEl.querySelector("#qab-collapse").addEventListener("click", () => setMinimized(true));
  panelEl.querySelector("#qab-mode").addEventListener("click", () => {
    setMode(uiState.mode === "post" ? "pre" : "post");
  });
  panelEl.querySelector("#qab-override-btn").addEventListener("click", () => {
    const val = panelEl.querySelector("#qab-override-input").value.trim();
    if (!val) return;
    manualOverride = val;
    manualReveal = false;
    runLookup(val, true, "manual");
  });
  panelEl.querySelector("#qab-override-clear").addEventListener("click", () => {
    manualOverride = null;
    lastQid = null; // force a fresh auto-detect + lookup on next poll
  });
  panelEl.querySelector("#qab-reveal-btn").addEventListener("click", () => {
    manualReveal = true;
    rerender();
  });
  makeDraggable(panelEl, panelEl.querySelector("#qab-header"));
  makeResizable(panelEl);

  // Saved position (if the user has dragged the panel before). Size, mode and
  // minimized state are applied by applyPanelUi() right below.
  if (uiState.position && uiState.position.top && uiState.position.left) {
    panelEl.style.top = uiState.position.top;
    panelEl.style.left = uiState.position.left;
    panelEl.style.bottom = "auto";
  }
  applyPanelUi();
  applyPageVisibility();
  return panelEl;
}

// Pushes uiState (mode label, minimized, size) onto the DOM. Safe to call
// any number of times.
function applyPanelUi() {
  if (!panelEl) return;
  panelEl.classList.toggle("qab-minimized", uiState.minimized);
  if (tabEl) tabEl.classList.toggle("qab-tab-show", uiState.minimized);

  const modeBtn = panelEl.querySelector("#qab-mode");
  modeBtn.textContent = uiState.mode === "post" ? "Dedicated" : "Pre-dedicated";
  modeBtn.title =
    uiState.mode === "post"
      ? "Dedicated mode: nothing about the cards is shown until you answer. Click to switch to Pre-dedicated."
      : "Pre-dedicated mode: active/suspended counts show as soon as the question loads. Click to switch to Dedicated.";

  if (uiState.size) {
    panelEl.style.width = `${Math.min(uiState.size.width, window.innerWidth - 8)}px`;
    panelEl.style.height = `${Math.min(uiState.size.height, window.innerHeight - 8)}px`;
    panelEl.style.maxHeight = "calc(100vh - 8px)";
  } else {
    panelEl.style.width = "";
    panelEl.style.height = "";
    panelEl.style.maxHeight = "";
  }
  if (!uiState.minimized) clampIntoViewport(panelEl);
}

// If the saved position/size came from a bigger window or monitor, pull the
// panel back on screen so it can't get stranded out of reach. (Skipped while
// minimized, because a hidden element has no measurable position.)
function clampIntoViewport(panel) {
  if (!panel.style.top) return; // still in the default bottom-left corner
  const rect = panel.getBoundingClientRect();
  const left = Math.min(Math.max(0, rect.left), Math.max(0, window.innerWidth - rect.width));
  const top = Math.min(Math.max(0, rect.top), Math.max(0, window.innerHeight - rect.height));
  panel.style.left = `${left}px`;
  panel.style.top = `${top}px`;
}

function setMinimized(minimized) {
  uiState.minimized = minimized;
  chrome.storage.local.set({ qab_minimized: minimized });
  applyPanelUi();
}

function setMode(mode) {
  uiState.mode = mode;
  chrome.storage.local.set({ qab_mode: mode });
  applyPanelUi();
  // Re-rendering rebuilds the cards area, which would wipe a half-typed note,
  // and once the answer is revealed the mode doesn't change what's shown anyway.
  if (!(lastAnswered || manualReveal)) rerender();
}

function resetPanelSize() {
  uiState.size = null;
  chrome.storage.local.remove("qab_size");
  applyPanelUi();
}

// Drag-to-reposition. The panel starts anchored bottom-left (via CSS);
// on the first drag it switches to an explicit top/left position so it
// can be placed anywhere, and that position is remembered across page
// reloads (per browser, via chrome.storage.local) until dragged again.
function makeDraggable(panel, handle) {
  let dragging = false;
  let offsetX = 0;
  let offsetY = 0;

  handle.addEventListener("mousedown", (e) => {
    if (e.target.closest("button")) return; // don't drag when clicking header buttons
    dragging = true;
    const rect = panel.getBoundingClientRect();
    panel.style.top = `${rect.top}px`;
    panel.style.left = `${rect.left}px`;
    panel.style.bottom = "auto";
    offsetX = e.clientX - rect.left;
    offsetY = e.clientY - rect.top;
    document.body.style.userSelect = "none";
    e.preventDefault();
  });

  document.addEventListener("mousemove", (e) => {
    if (!dragging) return;
    const maxX = window.innerWidth - panel.offsetWidth;
    const maxY = window.innerHeight - panel.offsetHeight;
    const newX = Math.min(Math.max(0, e.clientX - offsetX), Math.max(0, maxX));
    const newY = Math.min(Math.max(0, e.clientY - offsetY), Math.max(0, maxY));
    panel.style.left = `${newX}px`;
    panel.style.top = `${newY}px`;
  });

  document.addEventListener("mouseup", () => {
    if (!dragging) return;
    dragging = false;
    document.body.style.userSelect = "";
    uiState.position = { top: panel.style.top, left: panel.style.left };
    chrome.storage.local.set({ qab_position: uiState.position });
  });
}

// Drag-to-resize from two corner grips. The bottom-right grip grows the
// panel right/down; the top-right grip grows it right/up while keeping the
// bottom edge in place — that's the one you want when the panel is still
// sitting in its default spot at the bottom of the screen. Double-click
// either grip to go back to the default size. The size is remembered.
function makeResizable(panel) {
  let mode = null; // "br" | "tr" | null
  let startX = 0;
  let startY = 0;
  let startRect = null;
  const clamp = (v, lo, hi) => Math.min(Math.max(v, lo), Math.max(lo, hi));

  ["br", "tr"].forEach((corner) => {
    const grip = panel.querySelector(`#qab-grip-${corner}`);
    grip.addEventListener("mousedown", (e) => {
      mode = corner;
      startX = e.clientX;
      startY = e.clientY;
      startRect = panel.getBoundingClientRect();
      // Switch to explicit top/left anchoring so resizing is predictable.
      panel.style.top = `${startRect.top}px`;
      panel.style.left = `${startRect.left}px`;
      panel.style.bottom = "auto";
      panel.style.maxHeight = "calc(100vh - 8px)";
      document.body.style.userSelect = "none";
      e.preventDefault();
      e.stopPropagation();
    });
    grip.addEventListener("dblclick", resetPanelSize);
  });

  document.addEventListener("mousemove", (e) => {
    if (!mode) return;
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;
    const width = clamp(startRect.width + dx, MIN_W, window.innerWidth - startRect.left - 4);
    panel.style.width = `${width}px`;
    if (mode === "br") {
      panel.style.height = `${clamp(startRect.height + dy, MIN_H, window.innerHeight - startRect.top - 4)}px`;
    } else {
      const height = clamp(startRect.height - dy, MIN_H, startRect.bottom - 4);
      panel.style.height = `${height}px`;
      panel.style.top = `${startRect.bottom - height}px`;
    }
  });

  document.addEventListener("mouseup", () => {
    if (!mode) return;
    mode = null;
    document.body.style.userSelect = "";
    const rect = panel.getBoundingClientRect();
    uiState.size = { width: Math.round(rect.width), height: Math.round(rect.height) };
    uiState.position = { top: panel.style.top, left: panel.style.left };
    chrome.storage.local.set({ qab_size: uiState.size, qab_position: uiState.position });
  });
}

function renderLoading(qid) {
  const p = ensurePanel();
  setBanner(p, null);
  // Dedicated mode, question not answered yet: show the exact same quiet
  // screen from the first moment, so nothing flickers or changes while the
  // lookup finishes in the background.
  if (uiState.mode === "post" && !(lastAnswered || manualReveal)) {
    renderHidden(qid, lastConfidence);
    return;
  }
  p.querySelector("#qab-title").textContent = `Anki — QID ${qid ?? "?"}`;
  p.querySelector("#qab-status").textContent = "Looking up…";
  p.querySelector("#qab-compact-summary").innerHTML = "";
  p.querySelector("#qab-reveal-btn").style.display = "none";
  p.querySelector("#qab-cards").innerHTML = "";
}

function renderError(message) {
  const p = ensurePanel();
  setBanner(p, null);
  p.querySelector("#qab-status").textContent = `⚠ ${message}`;
  p.querySelector("#qab-compact-summary").innerHTML = "";
  p.querySelector("#qab-reveal-btn").style.display = "none";
  p.querySelector("#qab-cards").innerHTML = "";
}

function renderNoQid(needsAction) {
  const p = ensurePanel();
  setBanner(p, null);
  p.querySelector("#qab-title").textContent = "Anki";
  let msg;
  if (needsAction === "amboss-open-modal") {
    msg =
      "Open <strong>GET ANKI CARDS</strong> once on this question — the panel " +
      "reads the code from that dialog, then remembers it for this question.";
  } else if (needsAction === "amboss-code-not-found") {
    msg =
      "Found the \"Find related AnKing cards\" modal but couldn't isolate " +
      "the short code inside it. Type it into the box below (it's the short " +
      "text next to the copy icon, bottom-left of the modal), or use the " +
      "manual override.";
  } else {
    msg =
      "Couldn't detect a question ID on this page automatically. " +
      "Type it into the box below, or open the README to adjust " +
      "<code>extractQid()</code> for this site.";
  }
  p.querySelector("#qab-status").innerHTML = msg;
  p.querySelector("#qab-compact-summary").innerHTML = "";
  p.querySelector("#qab-reveal-btn").style.display = "none";
  p.querySelector("#qab-cards").innerHTML = "";
}

function renderNotFound(qid, query, confidence) {
  const p = ensurePanel();
  setBanner(p, null);
  const confidenceNote =
    confidence === "low"
      ? " This ID was a low-confidence guess (pulled from the URL) — " +
        "double check it's actually right before assuming the card is missing."
      : "";
  p.querySelector("#qab-status").innerHTML =
    `No Anki notes matched <code>${escapeHtml(query)}</code>.${confidenceNote} ` +
    `This question may not have a linked card, or your search template ` +
    `doesn't match this deck's tagging convention — check Options.`;
  p.querySelector("#qab-compact-summary").innerHTML = "";
  p.querySelector("#qab-reveal-btn").style.display = "none";
  p.querySelector("#qab-cards").innerHTML = "";
}

// Colored strip pinned under the header (it doesn't scroll away):
// kind = "ok" (green), "bad" (red), or null to hide it.
function setBanner(p, kind, text) {
  const el = p.querySelector("#qab-banner");
  if (!kind) {
    el.style.display = "none";
    el.textContent = "";
    el.className = "";
    return;
  }
  el.className = kind === "ok" ? "qab-banner-ok" : "qab-banner-bad";
  el.textContent = text;
  el.style.display = "block";
}

// The green/red verdict strip, shared by the pre-answer and post-answer views:
// green if every linked card is active, red if at least one is suspended.
function setStatusBanner(p, result) {
  const total = result.cards.length;
  const suspended = result.cards.filter((c) => c.suspended).length;
  const plural = total === 1 ? "card" : "cards";
  if (suspended === 0) {
    setBanner(p, "ok", `✓ All ${total} ${plural} active`);
  } else {
    setBanner(p, "bad", `⚠ ${suspended} of ${total} ${plural} suspended`);
  }
}

async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (_) {
    // fall through to the older approach
  }
  try {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    ta.remove();
    return ok;
  } catch (_) {
    return false;
  }
}

function escapeHtml(s) {
  const d = document.createElement("div");
  d.textContent = s;
  return d.innerHTML;
}

// Strips pasted/field HTML down to a small safe allowlist (bold, italic,
// underline, line breaks) and removes every attribute — used both for
// paste-into-Extra (so bold terms you copy from the question survive) and
// for the expanded card preview (so it displays with real formatting
// instead of flattened plain text). Anything not on the allowlist —
// spans with inline colors/fonts from the source site, scripts, etc. —
// gets unwrapped (its own tags removed, its content kept) rather than
// dropped outright, so no visible text is lost.
const ALLOWED_INLINE_TAGS = new Set(["B", "STRONG", "I", "EM", "U", "BR"]);
function sanitizeInlineHtml(html) {
  const container = document.createElement("div");
  container.innerHTML = html;

  function clean(node) {
    Array.from(node.childNodes).forEach((child) => {
      if (child.nodeType === Node.ELEMENT_NODE) {
        clean(child);
        if (ALLOWED_INLINE_TAGS.has(child.tagName)) {
          while (child.attributes.length > 0) {
            child.removeAttribute(child.attributes[0].name);
          }
        } else {
          while (child.firstChild) node.insertBefore(child.firstChild, child);
          node.removeChild(child);
        }
      } else if (child.nodeType !== Node.TEXT_NODE) {
        node.removeChild(child);
      }
    });
  }
  clean(container);
  return container.innerHTML;
}

// Inserts sanitized HTML at the current cursor position inside a
// contenteditable element, without relying on the deprecated
// document.execCommand.
function insertHtmlAtCursor(html) {
  const sel = window.getSelection();
  if (!sel || !sel.rangeCount) return;
  const range = sel.getRangeAt(0);
  range.deleteContents();
  const temp = document.createElement("div");
  temp.innerHTML = html;
  const frag = document.createDocumentFragment();
  let lastNode;
  while (temp.firstChild) {
    lastNode = frag.appendChild(temp.firstChild);
  }
  range.insertNode(frag);
  if (lastNode) {
    range.setStartAfter(lastNode);
    range.collapse(true);
    sel.removeAllRanges();
    sel.addRange(range);
  }
}

// Dedicated mode, before the question is answered: nothing about the cards
// is shown — not the counts, not even whether any cards exist.
function renderHidden(qid, confidence) {
  const p = ensurePanel();
  setBanner(p, null);
  const flag = confidence === "low" ? " ⚠" : "";
  p.querySelector("#qab-title").textContent = `Anki — QID ${qid}${flag}`;
  p.querySelector("#qab-status").textContent =
    "Cards hidden until you answer.";
  p.querySelector("#qab-compact-summary").innerHTML = "";
  p.querySelector("#qab-reveal-btn").style.display = "block";
  p.querySelector("#qab-cards").innerHTML = "";
}

// Compact, pre-answer view: counts only, no note content, so nothing here
// can spoil the question. Shown whenever cards are found but isAnswered()
// hasn't fired and the user hasn't manually revealed.
function renderCompactSummary(qid, result, confidence) {
  const p = ensurePanel();
  setStatusBanner(p, result); // same green/red strip as the full view
  const flag = confidence === "low" ? " ⚠" : "";
  p.querySelector("#qab-title").textContent = `Anki — QID ${qid}${flag}`;

  const total = result.cards.length;
  const suspended = result.cards.filter((c) => c.suspended).length;
  const active = total - suspended;

  p.querySelector("#qab-status").textContent =
    "Not answered yet — showing counts only";
  p.querySelector("#qab-compact-summary").innerHTML = `
    <div class="qab-compact-line">
      <span class="qab-badge qab-active">${active} active</span>
      <span class="qab-badge qab-suspended">${suspended} suspended</span>
      <span class="qab-reps">${total} card(s) linked</span>
    </div>`;
  p.querySelector("#qab-reveal-btn").style.display = "block";
  p.querySelector("#qab-cards").innerHTML = "";
}

// Full, post-answer view: note previews, suspend toggles, note-append box.
function renderFull(qid, result, alreadySeenThisSession, confidence) {
  const p = ensurePanel();
  const flag = confidence === "low" ? " ⚠" : "";
  p.querySelector("#qab-title").textContent = `Anki — QID ${qid}${flag}`;
  p.querySelector("#qab-title").title =
    confidence === "low" ? "Low-confidence auto-detect — verify this is the right question" : "";

  const anyReviewed = result.cards.some((c) => c.reps > 0);
  const statusBits = [
    `${result.notes.length} note(s), ${result.cards.length} card(s)`,
    anyReviewed ? "reviewed before" : "never reviewed",
    alreadySeenThisSession ? "seen earlier this session" : null
  ].filter(Boolean);
  p.querySelector("#qab-status").textContent = statusBits.join(" · ");

  // At-a-glance verdict, visible without scrolling through each card.
  setStatusBanner(p, result);
  p.querySelector("#qab-compact-summary").innerHTML = "";
  p.querySelector("#qab-reveal-btn").style.display = "none";

  const cardsHtml = result.notes
    .map((note) => {
      const noteCards = result.cards.filter((c) => note.cardIds.includes(c.cardId));
      const preview = firstFieldPreview(note.fields);
      const cardRows = noteCards
        .map(
          (c) => `
        <div class="qab-card-row" data-card-id="${c.cardId}">
          <span class="qab-badge ${c.suspended ? "qab-suspended" : "qab-active"}">
            ${c.suspended ? "suspended" : "active"}
          </span>
          <span class="qab-reps">${c.reps} rep(s)</span>
          <span class="qab-due">${escapeHtml(c.dueLabel ?? "")}</span>
          <button class="qab-toggle-suspend" data-card-id="${c.cardId}" data-suspend="${!c.suspended}">
            ${c.suspended ? "Unsuspend" : "Suspend"}
          </button>
          <button class="qab-again-btn" data-card-id="${c.cardId}" title="Grade this card Again in Anki">
            Again
          </button>
        </div>`
        )
        .join("");
      // Cards start fully expanded (data-expanded="true") — the truncated
      // span stays in the DOM (for the Show-less toggle) but hidden.
      return `
        <div class="qab-note" data-note-id="${note.noteId}">
          <div class="qab-note-preview" data-expanded="true">
            <span class="qab-preview-text" style="display:none">${escapeHtml(preview.truncatedText)}</span>
            ${preview.isTruncated ? `<button class="qab-expand-btn" type="button">Show less</button>` : ""}
            <div class="qab-preview-full">${preview.fullHtml}</div>
          </div>
          ${cardRows}
          <div class="qab-note-input" contenteditable="true" data-placeholder="Add a note to Extra…"></div>
          <button class="qab-save-note" data-note-id="${note.noteId}">Append to Extra</button>
          <button class="qab-copy-nid" data-note-id="${note.noteId}" title="Copies nid:${note.noteId} — paste it into Anki's Browse search to open just this note">Copy note ID</button>
        </div>`;
    })
    .join("");

  p.querySelector("#qab-cards").innerHTML = cardsHtml;

  p.querySelectorAll(".qab-expand-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const wrap = btn.closest(".qab-note-preview");
      const textSpan = wrap.querySelector(".qab-preview-text");
      const fullDiv = wrap.querySelector(".qab-preview-full");
      const expanded = wrap.dataset.expanded === "true";
      wrap.dataset.expanded = expanded ? "false" : "true";
      textSpan.style.display = expanded ? "" : "none";
      fullDiv.style.display = expanded ? "none" : "block";
      btn.textContent = expanded ? "Show more" : "Show less";
    });
  });

  // Paste into the note box: real pasted images (screenshots, copied
  // images) get uploaded straight into Anki's media folder via
  // AnkiConnect and inserted as <img>. Otherwise, bold/italic/underline
  // formatting survives the paste; everything else (colors, fonts, spans)
  // is stripped so it doesn't pollute the Anki field.
  //
  // preventDefault() and stopImmediatePropagation() are called as the
  // very first thing, unconditionally, before any other logic — this
  // guards against the double-paste seen in practice, where the most
  // likely cause is the browser's own native paste still going through
  // alongside our manual insertion (rather than a clean single bug),
  // given the duplicated text wasn't an exact copy of itself. The
  // data-qab-paste-bound guard below is a second, cheap defense in case
  // this element ever ends up with the listener attached more than once.
  p.querySelectorAll(".qab-note-input").forEach((el) => {
    if (el.dataset.qabPasteBound === "true") return;
    el.dataset.qabPasteBound = "true";
    el.addEventListener("paste", (e) => {
      e.preventDefault();
      e.stopImmediatePropagation();
      el.focus();

      const items = Array.from(e.clipboardData.items || []);
      const imageItem = items.find((it) => it.kind === "file" && it.type.startsWith("image/"));

      if (imageItem) {
        const blob = imageItem.getAsFile();
        const reader = new FileReader();
        reader.onload = async () => {
          const base64 = String(reader.result).split(",")[1];
          const ext = (imageItem.type.split("/")[1] || "png").toLowerCase();
          const filename = `qab_paste_${Date.now()}.${ext}`;
          const resp = await chrome.runtime.sendMessage({
            type: "ANKI_STORE_MEDIA",
            filename,
            dataBase64: base64
          });
          if (resp.ok) {
            insertHtmlAtCursor(`<img src="${resp.filename}">`);
          } else {
            console.error("[QBank-Anki Bridge] image paste failed:", resp.error);
          }
        };
        reader.readAsDataURL(blob);
        return;
      }

      const html = e.clipboardData.getData("text/html");
      const text = e.clipboardData.getData("text/plain");
      const sanitized = html ? sanitizeInlineHtml(html) : escapeHtml(text);
      insertHtmlAtCursor(sanitized);
    });
  });

  p.querySelectorAll(".qab-toggle-suspend").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const cardId = Number(btn.dataset.cardId);
      const suspend = btn.dataset.suspend === "true";
      btn.disabled = true;
      const resp = await chrome.runtime.sendMessage({
        type: "ANKI_TOGGLE_SUSPEND",
        cardIds: [cardId],
        suspend
      });
      if (resp.ok) {
        runLookup(qid, true, confidence); // refresh, keeps current reveal state
      } else {
        renderError(resp.error);
      }
    });
  });

  p.querySelectorAll(".qab-again-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const cardId = Number(btn.dataset.cardId);
      btn.disabled = true;
      const original = btn.textContent;
      btn.textContent = "…";
      const resp = await chrome.runtime.sendMessage({
        type: "ANKI_ANSWER_CARD",
        cardId,
        ease: 1
      });
      if (resp.ok) {
        btn.textContent = "Again ✓";
        runLookup(qid, true, confidence); // refresh rep counts etc.
      } else {
        btn.disabled = false;
        btn.textContent = original;
        renderError(resp.error);
      }
    });
  });

  p.querySelectorAll(".qab-copy-nid").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const ok = await copyToClipboard(`nid:${btn.dataset.noteId}`);
      btn.textContent = ok ? "Copied ✓" : "Copy failed";
      setTimeout(() => (btn.textContent = "Copy note ID"), 1200);
    });
  });

  p.querySelectorAll(".qab-save-note").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const noteId = Number(btn.dataset.noteId);
      const noteEl = btn.closest(".qab-note");
      const inputEl = noteEl.querySelector(".qab-note-input");
      const text = inputEl.innerHTML.trim();
      if (!text || !inputEl.textContent.trim()) return;
      const note = result.notes.find((n) => n.noteId === noteId);
      const currentValue = note ? note.fields["Extra"] || "" : "";
      btn.disabled = true;
      btn.textContent = "Saving…";
      const resp = await chrome.runtime.sendMessage({
        type: "ANKI_APPEND_NOTE",
        noteId,
        currentValue,
        appendText: text,
        site: SITE
      });
      btn.disabled = false;
      btn.textContent = resp.ok ? "Saved ✓" : "Failed";
      if (resp.ok) inputEl.innerHTML = "";
    });
  });
}

function firstFieldPreview(fields) {
  const key = Object.keys(fields)[0];
  const original = fields[key] || "";
  const plain = original.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
  const isTruncated = plain.length > 120;
  return {
    truncatedText: isTruncated ? plain.slice(0, 117) + "…" : plain || "(empty)",
    fullHtml: sanitizeInlineHtml(original) || "(empty)",
    isTruncated
  };
}

// Re-render the cached result (no network call) using the current
// answered/reveal state. Used both right after a fresh lookup and when
// only the answered-state changes on the same question.
function rerender() {
  if (!lastQid || !lastResult) return;
  const revealed = lastAnswered || manualReveal;
  if (!revealed && uiState.mode === "post") {
    renderHidden(lastQid, lastConfidence);
  } else if (!lastResult.found) {
    renderNotFound(lastQid, lastResult.query, lastConfidence);
  } else if (revealed) {
    renderFull(lastQid, lastResult, lastSeenBefore, lastConfidence);
  } else {
    renderCompactSummary(lastQid, lastResult, lastConfidence);
  }
}

// ---- 3. Lookup + polling for SPA navigation --------------------------------

async function runLookup(qid, forceRefresh = false, confidence = "manual", needsAction = null) {
  if (!forceRefresh && qid === lastQid) return;
  const isNewQuestion = qid !== lastQid;
  lastQid = qid;
  lastConfidence = confidence;
  lastResult = null;

  if (!qid) {
    renderNoQid(needsAction);
    return;
  }

  renderLoading(qid);
  // Remember whether this QID was seen BEFORE this visit, then record it.
  if (isNewQuestion) lastSeenBefore = seenQids.has(qid);
  seenQids.add(qid);
  await chrome.storage.local.set({
    [`qab_seen_${qid}`]: { site: SITE, seenAt: Date.now() }
  });

  const resp = await chrome.runtime.sendMessage({ type: "ANKI_LOOKUP", qid, site: SITE });
  if (qid !== lastQid) return; // you've already moved on to another question
  if (!resp.ok) {
    renderError(resp.error);
    return;
  }
  // Both "found" and "not found" go through rerender() so Dedicated mode can
  // hide either one until you've answered.
  lastResult = resp;
  rerender();
}

// The panel only makes sense while you're actually inside a question. On
// UWorld that's the test interface (".../testinterface/..."); the dashboard,
// planner, previous-tests list etc. get no panel and no tab at all.
// On Amboss it's the question view (/us/questions/<session>/<number>).
function isQuestionPage() {
  if (SITE === "uworld") return location.pathname.toLowerCase().includes("/testinterface/");
  // Amboss: a question address looks like /us/questions/<session id>/<number>;
  // the GET ANKI CARDS button is the backup signal if that ever changes.
  if (/\/questions\/[^/]+\/\d+/.test(location.pathname)) return true;
  return Array.from(document.querySelectorAll('button, [role="button"], a')).some((el) =>
    /get anki cards/i.test(el.textContent || "")
  );
}

function applyPageVisibility() {
  if (!panelEl) return;
  const off = pageActive === false;
  panelEl.classList.toggle("qab-offpage", off);
  if (tabEl) tabEl.classList.toggle("qab-offpage", off);
}

function setPageActive(active) {
  if (active === pageActive) return;
  pageActive = active;
  if (!active) {
    // Leaving the question: forget per-question state (this also cancels any
    // lookup still in flight) so coming back starts clean.
    lastQid = null;
    lastNoQidKey = null;
    lastResult = null;
    lastAnswered = false;
    manualReveal = false;
    manualOverride = null;
  }
  applyPageVisibility();
}

function poll() {
  if (!uiReady) return; // saved UI state (mode/minimized/size) hasn't loaded yet
  setPageActive(isQuestionPage());
  if (!pageActive) return;
  const answered = isAnswered();

  if (manualOverride) {
    if (answered !== lastAnswered) {
      lastAnswered = answered;
      rerender();
    }
    return;
  }

  const { qid, confidence, needsAction } = extractQid();
  // When there's no ID yet (Amboss, before the dialog's been opened) we still
  // want to show the hint, and to refresh it when the question changes.
  const noQidKey = qid ? null : `${needsAction || "none"}|${location.pathname}`;
  if (qid !== lastQid || noQidKey !== lastNoQidKey) {
    lastNoQidKey = noQidKey;
    manualReveal = false; // fresh question — don't carry over a prior reveal
    lastAnswered = answered;
    runLookup(qid, qid === null, confidence, needsAction);
  } else if (answered !== lastAnswered) {
    lastAnswered = answered;
    rerender();
  }
}

// Prevents arrow-key (and similar) navigation while typing inside the
// panel's own text fields from also being caught by the underlying
// page's own keyboard-shortcut handler (which is what was advancing you
// to the next/previous question while you were just trying to move the
// cursor). Registered on `document` in the capture phase, which runs
// before bubble-phase listeners the page itself likely uses — this is a
// best-effort mitigation, not a guarantee, since I can't see whether
// UWorld/Amboss registers their own handler in the capture phase too; if
// this still happens on a particular site, that's the sign of that.
const GUARDED_KEYS = new Set(["ArrowLeft", "ArrowRight"]);
document.addEventListener(
  "keydown",
  (e) => {
    if (GUARDED_KEYS.has(e.key) && e.target && e.target.closest && e.target.closest("#qab-panel")) {
      e.stopPropagation();
    }
  },
  true
);

// UWorld/Amboss are single-page apps — the URL and DOM change without a
// full reload between questions, so a plain "run once on load" won't
// catch navigation, and won't catch the answered/unanswered transition
// either. Polling every second is cheap and reliable; a MutationObserver
// is used too so updates feel closer to instant.
//
// Everything here is wrapped so a thrown error is visible in the console
// (prefixed for easy searching) instead of silently stopping the whole
// script partway through — which would otherwise look exactly like "the
// extension isn't doing anything on this page."
try {
  setInterval(() => {
    try {
      poll();
    } catch (err) {
      console.error("[QBank-Anki Bridge] poll() failed:", err);
    }
  }, 1000);

  const observer = new MutationObserver(() => {
    try {
      poll();
    } catch (err) {
      console.error("[QBank-Anki Bridge] MutationObserver poll() failed:", err);
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });

  // Restore previously-seen QIDs for this browser so "seen before" survives
  // a page reload, and load the saved UI state (mode, minimized, size,
  // position). poll() is held back until this finishes (uiReady) so a saved
  // Dedicated mode is already in force before anything is rendered.
  chrome.storage.local.get(null).then((all) => {
    Object.keys(all).forEach((k) => {
      if (k.startsWith("qab_seen_")) seenQids.add(k.replace("qab_seen_", ""));
      if (k.startsWith("qab_ac_")) ambossCodes.set(k.slice("qab_ac_".length), all[k]);
    });
    uiState.mode = all.qab_mode === "post" ? "post" : "pre";
    uiState.minimized = !!all.qab_minimized;
    if (all.qab_size && all.qab_size.width && all.qab_size.height) uiState.size = all.qab_size;
    if (all.qab_position && all.qab_position.top && all.qab_position.left) {
      uiState.position = all.qab_position;
    }
    uiReady = true;
    poll();
  });

  // Keep every open UWorld/Amboss frame and tab in sync: change the mode or
  // minimize in one place and the others follow.
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    let modeChanged = false;
    let apply = false;
    if (changes.qab_mode) {
      const next = changes.qab_mode.newValue === "post" ? "post" : "pre";
      if (next !== uiState.mode) {
        uiState.mode = next;
        modeChanged = true;
        apply = true;
      }
    }
    if (changes.qab_minimized) {
      const next = !!changes.qab_minimized.newValue;
      if (next !== uiState.minimized) {
        uiState.minimized = next;
        apply = true;
      }
    }
    if (changes.qab_size) {
      const next = changes.qab_size.newValue || null;
      if (JSON.stringify(next) !== JSON.stringify(uiState.size)) {
        uiState.size = next;
        apply = true;
      }
    }
    if (apply) applyPanelUi();
    if (modeChanged && !(lastAnswered || manualReveal)) rerender();
  });

  // Keep the panel reachable if the window gets smaller.
  window.addEventListener("resize", () => applyPanelUi());

  console.log("[QBank-Anki Bridge] content script loaded on", location.hostname);
} catch (err) {
  console.error("[QBank-Anki Bridge] setup failed:", err);
}
