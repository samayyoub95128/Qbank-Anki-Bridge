// background.js
// All communication with AnkiConnect happens here, in the extension's
// service worker, rather than in the content script. This keeps the
// CORS story simple: you only ever need to allow ONE origin
// (chrome-extension://<this-extension-id>) in AnkiConnect's config,
// and it isn't affected by whatever CSP UWorld/Amboss ship on their pages.

const DEFAULT_SETTINGS = {
  ankiConnectUrl: "http://127.0.0.1:8765",
  // UWorld: numeric leaf, e.g. #AK_Step1_v12::#UWorld::Step::22124
  uworldSearchTemplate: "tag:#AK_Step1_v12::#UWorld::Step::{qid}",
  // Amboss: AnKing generates a short code (not a number) per question, only
  // visible via the "GET ANKI CARDS" button — e.g. #AK_Step1_v12::#AMBOSS::y0adiQ
  ambossSearchTemplate: "tag:#AK_Step1_v12::#AMBOSS::{qid}",
  extraFieldName: "Extra"
};

async function getSettings() {
  const stored = await chrome.storage.sync.get(DEFAULT_SETTINGS);
  return stored;
}

async function ankiRequest(action, params = {}) {
  const { ankiConnectUrl } = await getSettings();
  const res = await fetch(ankiConnectUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action, version: 6, params })
  });
  if (!res.ok) {
    throw new Error(`AnkiConnect HTTP ${res.status} — is Anki open with AnkiConnect installed?`);
  }
  const data = await res.json();
  if (data.error) throw new Error(data.error);
  return data.result;
}

async function handleLookup(qid, site) {
  const settings = await getSettings();
  const template = site === "amboss" ? settings.ambossSearchTemplate : settings.uworldSearchTemplate;
  const query = template.replace("{qid}", qid);

  const noteIds = await ankiRequest("findNotes", { query });
  if (!noteIds.length) {
    return { found: false, query };
  }

  const notesInfo = await ankiRequest("notesInfo", { notes: noteIds });
  const cardIds = notesInfo.flatMap((n) => n.cards);
  const suspended = await ankiRequest("areSuspended", { cards: cardIds });
  const cardsInfo = await ankiRequest("cardsInfo", { cards: cardIds });
  const dueLabels = await attachDueLabels(cardsInfo);

  const cardsById = new Map(cardsInfo.map((c) => [c.cardId, c]));

  return {
    found: true,
    query,
    notes: notesInfo.map((n) => ({
      noteId: n.noteId,
      modelName: n.modelName,
      fields: Object.fromEntries(
        Object.entries(n.fields).map(([k, v]) => [k, v.value])
      ),
      tags: n.tags,
      cardIds: n.cards
    })),
    cards: cardIds.map((cardId, i) => {
      const info = cardsById.get(cardId) || {};
      return {
        cardId,
        suspended: suspended[i],
        reps: info.reps ?? 0,
        interval: info.interval ?? 0,
        due: info.due ?? null,
        dueLabel: dueLabels[cardId] || "—"
      };
    })
  };
}

async function handleToggleSuspend(cardIds, suspend) {
  await ankiRequest(suspend ? "suspend" : "unsuspend", { cards: cardIds });
  return { ok: true };
}

async function handleStoreMedia(filename, dataBase64) {
  const actualFilename = await ankiRequest("storeMediaFile", {
    filename,
    data: dataBase64
  });
  return { ok: true, filename: actualFilename || filename };
}

// Anki doesn't expose a plain "due date" field. For queue=2/3 (review)
// cards, the raw `due` value AnkiConnect returns is days-since-collection-
// creation, not a calendar date — and there's no AnkiConnect action that
// hands back the collection's creation date to convert it. Instead, this
// uses Anki's own `prop:due<=N` search operator, which IS defined
// relative to today, to bucket each card into the tightest N-day window
// it falls due within, then converts that to an approximate calendar
// date. It's a genuine approximation (bounded by the threshold list
// below), not a guaranteed-exact date — treat "Due ~8/27/26" as "by
// then," not "exactly then."
const DUE_THRESHOLDS = [0, 1, 2, 3, 5, 7, 10, 14, 21, 30, 45, 60, 90, 180, 365];

function formatDateShort(date) {
  const mm = date.getMonth() + 1;
  const dd = date.getDate();
  const yy = String(date.getFullYear()).slice(-2);
  return `${mm}/${dd}/${yy}`;
}

async function attachDueLabels(cardsInfo) {
  const labels = {};
  const needsSearch = [];

  for (const c of cardsInfo) {
    if (c.queue === -1) {
      labels[c.cardId] = ""; // the ACTIVE/SUSPENDED badge already says this — leave the slot empty
    } else if (c.queue === 0) {
      labels[c.cardId] = "New";
    } else if ((c.queue === 1 || c.queue === 3) && c.due > 1000000000) {
      // Learning queue: due is a Unix timestamp (seconds), so this one IS exact.
      labels[c.cardId] = `Due ${formatDateShort(new Date(c.due * 1000))}`;
    } else {
      needsSearch.push(c.cardId);
    }
  }

  const remaining = new Set(needsSearch);
  for (const days of DUE_THRESHOLDS) {
    if (remaining.size === 0) break;
    const idClause = [...remaining].map((id) => `cid:${id}`).join(" OR ");
    const matched = await ankiRequest("findCards", { query: `(${idClause}) prop:due<=${days}` });
    const matchedSet = new Set(matched);
    for (const cid of [...remaining]) {
      if (matchedSet.has(cid)) {
        labels[cid] =
          days === 0 ? "Due now" : `Due ~${formatDateShort(new Date(Date.now() + days * 86400000))}`;
        remaining.delete(cid);
      }
    }
  }
  for (const cid of remaining) labels[cid] = ">1yr out";

  return labels;
}

async function handleAnswerCard(cardId, ease) {
  // ease: 1=Again, 2=Hard, 3=Good, 4=Easy. AnkiConnect's answerCards only
  // works on cards that are actually due/in the review queue — a brand
  // new or not-yet-due card can fail here, which surfaces as an error in
  // the panel rather than silently doing nothing.
  const results = await ankiRequest("answerCards", {
    answers: [{ cardId, ease }]
  });
  if (!results || !results[0]) {
    throw new Error(
      "Anki didn't accept that grade — the card may not be due/in the review queue right now."
    );
  }
  return { ok: true };
}

async function handleAppendNote(noteId, currentValue, appendText, site) {
  const { extraFieldName } = await getSettings();
  // The ENTIRE appended note is underlined, prefix included — the Anki Format
  // Shuffler add-on recolors underlined text, so this is what makes your notes
  // stand out on the card. Any <u> tags already inside the note (from a paste)
  // are removed first so they don't nest inside the wrapper.
  const label = site ? `${site.toUpperCase()}: ` : "";
  const cleaned = String(appendText).replace(/<\/?u>/gi, "");
  const prefixedText = `<u>${label}${cleaned}</u>`;
  const separator = currentValue && currentValue.trim().length ? "<br><br>" : "";
  const newValue = `${prefixedText}${separator}${currentValue || ""}`;
  await ankiRequest("updateNoteFields", {
    note: { id: noteId, fields: { [extraFieldName]: newValue } }
  });
  return { ok: true, newValue };
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    try {
      switch (msg.type) {
        case "ANKI_LOOKUP":
          sendResponse({ ok: true, ...(await handleLookup(msg.qid, msg.site)) });
          break;
        case "ANKI_TOGGLE_SUSPEND":
          sendResponse({ ok: true, ...(await handleToggleSuspend(msg.cardIds, msg.suspend)) });
          break;
        case "ANKI_ANSWER_CARD":
          sendResponse({ ok: true, ...(await handleAnswerCard(msg.cardId, msg.ease)) });
          break;
        case "ANKI_STORE_MEDIA":
          sendResponse({ ok: true, ...(await handleStoreMedia(msg.filename, msg.dataBase64)) });
          break;
        case "ANKI_APPEND_NOTE":
          sendResponse({
            ok: true,
            ...(await handleAppendNote(msg.noteId, msg.currentValue, msg.appendText, msg.site))
          });
          break;
        case "ANKI_PING":
          await ankiRequest("version");
          sendResponse({ ok: true });
          break;
        default:
          sendResponse({ ok: false, error: `Unknown message type: ${msg.type}` });
      }
    } catch (err) {
      sendResponse({ ok: false, error: String(err.message || err) });
    }
  })();
  return true; // keep the message channel open for the async response
});
