const DEFAULTS = {
  ankiConnectUrl: "http://127.0.0.1:8765",
  uworldSearchTemplate: "tag:#AK_Step1_v12::#UWorld::Step::{qid}",
  ambossSearchTemplate: "tag:#AK_Step1_v12::#AMBOSS::{qid}",
  extraFieldName: "Extra"
};

async function load() {
  const settings = await chrome.storage.sync.get(DEFAULTS);
  document.getElementById("ankiConnectUrl").value = settings.ankiConnectUrl;
  document.getElementById("uworldSearchTemplate").value = settings.uworldSearchTemplate;
  document.getElementById("ambossSearchTemplate").value = settings.ambossSearchTemplate;
  document.getElementById("extraFieldName").value = settings.extraFieldName;
}

async function save() {
  const settings = {
    ankiConnectUrl: document.getElementById("ankiConnectUrl").value.trim() || DEFAULTS.ankiConnectUrl,
    uworldSearchTemplate:
      document.getElementById("uworldSearchTemplate").value.trim() || DEFAULTS.uworldSearchTemplate,
    ambossSearchTemplate:
      document.getElementById("ambossSearchTemplate").value.trim() || DEFAULTS.ambossSearchTemplate,
    extraFieldName: document.getElementById("extraFieldName").value.trim() || DEFAULTS.extraFieldName
  };
  await chrome.storage.sync.set(settings);
  const status = document.getElementById("status");
  status.textContent = "Saved.";
  setTimeout(() => (status.textContent = ""), 1500);
}

async function testConnection() {
  const status = document.getElementById("status");
  status.textContent = "Testing…";
  const resp = await chrome.runtime.sendMessage({ type: "ANKI_PING" });
  status.textContent = resp.ok
    ? "✓ Connected to AnkiConnect."
    : `✗ ${resp.error} (Is Anki open? Is AnkiConnect installed and CORS-configured?)`;
}

document.getElementById("save").addEventListener("click", save);
document.getElementById("testConnection").addEventListener("click", testConnection);
load();
